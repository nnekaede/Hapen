package com.example.nnekaede.recylclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    //vars
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG,"onCreate: started.");

        initImageBitmaps();


    }

    private void initImageBitmaps(){
        Log.d(TAG, "initImageBitmaps: preparing bitmaps.");

        mImageUrls.add("https://alltogether.swe.org/wp-content/uploads/2018/05/SWE-Logo-Gray-Background-e1463523395680.jpg");
        mNames.add("Society of Women Engineers");

        mImageUrls.add("https://www.acm.org/binaries/content/gallery/acm/ctas/ambassadors-for-acm.jpg/ambassadors-for-acm.jpg/acm%3Adesktopcta");
        mNames.add("Association of Computing Machinery");

        mImageUrls.add("https://upload.wikimedia.org/wikipedia/en/thumb/e/ea/NSBE_organization_logo.png/220px-NSBE_organization_logo.png");
        mNames.add("National Society of Black Engineers");

        mImageUrls.add("https://pbs.twimg.com/profile_images/1028220746701697024/4zJphHM7_400x400.jpg");
        mNames.add("African Student Association");


        mImageUrls.add("https://nabaphilly.org/wp-content/uploads/2014/09/cropped-naba_logo-e1503146045204.jpg");
        mNames.add("National Association of Black Accountants ");

        mImageUrls.add("https://pbs.twimg.com/profile_images/867773389766893568/u52eecrL_400x400.jpg");
        mNames.add("Purple Jackets");


        mImageUrls.add("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkAaU9zwEOUIOU4JqjIKmKRDhpDDjQzihefKCG4gcw7CSu-znq");
        mNames.add("Institute of Electrical and Electronics Engineers");

        mImageUrls.add("https://www.fxu.org.uk/asset/Organisation/6206/square%20logo.jpg?thumbnail_width=250&thumbnail_height=250&resize_type=CropToFit&fill_colour=cccccc");
        mNames.add("Enactus");

        mImageUrls.add("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ81GsFJ05OHdj75pgzOvkPkzqOwErw_m_VxUP2lUqFl2j2SkV22Q");
        mNames.add("Minority Association of Pre-Med Students");

        initRecyclerView();

    }

    private void initRecyclerView(){
        Log.d(TAG, "initRecyclerView: init recyclerview.");
        RecyclerView recyclerView = findViewById(R.id.recyclerv_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(mNames, mImageUrls, this);
        recyclerView.setAdapter(adapter);
        //RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mNames, mImageUrls);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
}
